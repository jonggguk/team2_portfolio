-- ȸ������ ���̺� ����
CREATE TABLE PC_USER(
 U_NUM NUMBER(3), 
 U_NAME VARCHAR2(20) NOT NULL, 
 U_ID VARCHAR2(20) NOT NULL, 
 U_PWD VARCHAR2(20) NOT NULL, 
 U_JUMIN VARCHAR2(20) NOT NULL, 
 U_EMAIL VARCHAR2(40), 
 U_ADDRESS VARCHAR2(80), 
 U_TIME NUMBER(6) DEFAULT 300, 
 U_LEVEL VARCHAR2(50) DEFAULT '�Ϲ�ȸ��', 
 U_RGDATE DATE, 
 U_LASTUSE DATE, 
 U_MILEAGE NUMBER(10)
);

--������ ���̺� ����
CREATE TABLE PC_MANAGER(
    m_ID VARCHAR2(12) PRIMARY KEY,
    m_PWD VARCHAR2(12) NOT NULL
);

-- ���� ���̺� ����
create table pc_food(
    f_code number(4) PRIMARY key,
    f_name varchar2(30),
    f_price varchar2(15),
    f_amount number(3)
);

-- �ֹ� ���̺� ����
--create table pc_order(
--);

-- ȸ�� ������ ����
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (1, 'a1', 'test1', '1', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (2, 'a2', 'aaaaa2', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (3, 'a3', 'aaaaa3', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (4, 'a4', 'aaaaa4', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (5, 'a5', 'aaaaa5', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (6, 'a6', 'aaaaa6', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (7, 'a7', 'aaaaa7', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (8, 'a8', 'aaaaa8', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (9, 'a9', 'aaaaa9', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (10, 'a10', 'aaaaa10', 'a', 'aaaaaaaaaaaaa', 'a', 'a', 14616, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 406);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (11, 'b11', 'bbbbb1', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (12, 'b12', 'bbbbb2', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (13, 'b13', 'bbbbb3', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (14, 'b14', 'bbbbb4', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (15, 'b15', 'bbbbb5', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (16, 'b16', 'bbbbb6', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (17, 'b17', 'bbbbb7', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (18, 'b18', 'bbbbb8', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (19, 'b19', 'bbbbb9', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);
INSERT INTO pc_user(U_NUM,U_NAME,U_ID,U_PWD,U_JUMIN,U_EMAIL,U_ADDRESS,U_TIME,U_LEVEL ,U_RGDATE, U_LASTUSE , U_MILEAGE) VALUES (20, 'b20', 'bbbbb10', 'b', 'bbbbbbbbbbbbb', 'b', 'b', 14617, '�Ϲ�ȸ��', '21/05/27', '21/05/27', 407);

--������ ������ ����
INSERT INTO pc_manager(m_id, m_pwd) VALUES ('admin', '1234');

-- ���� ������ ����
INSERT INTO pc_food(f_code, f_name, f_price, f_amount) VALUES (1, '�����', '2500', 100);
INSERT INTO pc_food(f_code, f_name, f_price, f_amount) VALUES (2, '��«��', '2500', 100);
INSERT INTO pc_food(f_code, f_name, f_price, f_amount) VALUES (3, '�ܹ���', '2500', 100);
INSERT INTO pc_food(f_code, f_name, f_price, f_amount) VALUES (4, '��ī��', '2500', 100);
INSERT INTO pc_food(f_code, f_name, f_price, f_amount) VALUES (5, 'Ŀ��', '2500', 100);
INSERT INTO pc_food(f_code, f_name, f_price, f_amount) VALUES (6, '��', '2500', 100);

commit;

--drop table pc_user;
select * From pc_user;
select * from pc_manager;