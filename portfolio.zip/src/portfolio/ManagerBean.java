package portfolio;

public class ManagerBean {
	private String m_id;
	private String m_pwd;
	
	String getM_id() {
		return m_id;
	}
	void setM_id(String m_id) {
		this.m_id = m_id;
	}
	String getM_pwd() {
		return m_pwd;
	}
	void setM_pwd(String m_pwd) {
		this.m_pwd = m_pwd;
	}
	
}
