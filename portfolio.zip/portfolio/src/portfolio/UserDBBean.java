package portfolio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import myUtil.HanConv;

public class UserDBBean {
	private static UserDBBean instance = new UserDBBean();

	public static UserDBBean getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}

	public int insertUser(UserBean user) throws Exception { // ȸ�� ���Խ� ��� �� �޼ҵ�
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int re = -1;
		int num;

		try {

			conn = getConnection();
			sql = "SELECT max(u_num) FROM pc_user";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				num = rs.getInt(1) + 1;
			} else {
				num = 1;
			}

			sql = "insert into pc_user (u_num,u_name,u_id,u_pwd,u_jumin,u_email,u_address,u_rgdate)"
					+ "values(?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, HanConv.toKor(user.getU_name()));
			pstmt.setString(3, user.getU_id());
			pstmt.setString(4, user.getU_pwd());
			pstmt.setString(5, user.getU_jumin());
			pstmt.setString(6, user.getU_email());
			pstmt.setString(7, HanConv.toKor(user.getU_address()));
			pstmt.setTimestamp(8, user.getU_rgdate());
			// ���⼭ �ð� �� �����Ͽ� ���� ����̴� ���� �ʴ´�
			// psmtm.setInt(8,user.getU_time());

			pstmt.executeUpdate();

			re = 1;

		} catch (Exception e) {
			System.out.println("�ý��� ���� ");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return re;
	}

	public int confirmID(String id) throws Exception { // �α��ν� ID�� ����Ǿ��ִ� ȸ������ Ȯ��
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select u_id from pc_user where u_id=?";
		int re = -1;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				re = 1;
			} else {
				re = -1;
			}
			rs.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return re;
	}

	public int userCheck(String id, String pwd) throws Exception { // ���̵�� ��й�ȣ�� ��ġ����
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int re = -1;
		String db_u_pwd = "";
		String sql = "select u_pwd from pc_user where u_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				db_u_pwd = rs.getString("u_pwd");
				if (db_u_pwd.equals(pwd)) {
					re = 1;
				} else {
					re = 0;
				}
			} else {
				re = -1;
			}
			rs.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return re;

	}

	public UserBean getUser(String id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from pc_user where u_id=?";
		UserBean user = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				user = new UserBean();
				user.setU_num(rs.getInt("u_num"));
				user.setU_name(rs.getString("u_name"));
				user.setU_id(rs.getString("u_id"));
				user.setU_pwd(rs.getString("u_pwd"));
				user.setU_jumin(rs.getString("u_jumin"));
				user.setU_email(rs.getString("u_email"));
				user.setU_address(rs.getString("u_address"));
				user.setU_time(rs.getInt("u_time"));
				user.setU_level(rs.getNString("u_level"));
				user.setU_rgdate(rs.getTimestamp("u_rgdate"));
				user.setU_lastuse(rs.getTimestamp("u_lastuse"));
			}
			
		} catch (Exception e) {
			System.out.println("�ý��� ���� ");
			e.printStackTrace();
		}finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
				if (rs!=null)
					rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return user;

	}

	
	public int updateUser(UserBean user) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int re = -1;
		String sql = "update pc_user set u_pwd = ?,u_email=?,u_address=? where u_id=?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getU_pwd());
			pstmt.setString(2, user.getU_email());
			pstmt.setString(3, HanConv.toKor(user.getU_address()));
			pstmt.setString(4, user.getU_id());
			re = pstmt.executeUpdate();

			
			pstmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return re;
	}

	public int endPC( UserBean user ,int time) throws Exception {
		
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int re = -1;
		String sql = "update pc_user  set u_time =  ? , u_lastuse = ?   where u_id = ?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, time);
			pstmt.setTimestamp(2,user.getU_lastuse() );
			pstmt.setString(3,user.getU_id());

			re = pstmt.executeUpdate();

			
			sql ="update pc_user set u_mileage = u_time/36 WHERE u_id = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getU_id());
			re = pstmt.executeUpdate();
		
			
			sql = "update pc_user set u_level = 'VIP' WHERE u_id = ? and u_time/3600 >10 ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getU_id());
			re = pstmt.executeUpdate();
			
			pstmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return re;
	}
	public ArrayList<UserBean> listUser(String pageNumber){
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSet pageSet = null;		
		
		int dbCount = 0;
		int absoultePage = 1; //���� ������
		String sql = "";

		ArrayList<UserBean> UserList = new ArrayList<UserBean>();
		
		try {
			con = getConnection();
			stmt = con.createStatement();
			pageSet = stmt.executeQuery("select count(u_id) from pc_user");
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			// pageCount ���ϱ�
			if(dbCount % UserBean.pageSize == 0) {
				UserBean.pageCount = dbCount / UserBean.pageSize;
			} else {
				UserBean.pageCount = dbCount / UserBean.pageSize + 1;				
			}

			if(pageNumber != null){
				UserBean.pageNum =  Integer.parseInt(pageNumber);
				absoultePage = (UserBean.pageNum - 1) * UserBean.pageSize + 1; // 1 > 11 > 21 > 31
			}			

			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE); //��Ʈ1
			sql = "select u_num, u_name, u_id,u_pwd ,u_level, u_jumin, u_lastuse, u_mileage from pc_user order by u_num asc";
			rs = stmt.executeQuery(sql);	
			
			if(rs.next()) {
				rs.absolute(absoultePage); //��Ʈ2
				int count = 0;
				
				while (count < UserBean.pageSize) {
					UserBean user = new UserBean();
					user.setU_num(rs.getInt(1));
					user.setU_name(rs.getString(2));
					user.setU_id(rs.getString(3));
					user.setU_pwd(rs.getNString(4));
					user.setU_level(rs.getString(5));
					user.setU_jumin(rs.getString(6));
					user.setU_lastuse(rs.getTimestamp(7));
					user.setU_mileage(rs.getInt(8));
					

					UserList.add(user);
					
				 if(rs.isLast()) {
					 break;
				 }else {
					 rs.next();
				 }
				 count++;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if (stmt != null) stmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return UserList;
	}
	public int deleteUser(String u_id , String u_pwd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int re = -1;
		String pwd;
		try {
			conn = getConnection();
			sql = "select u_pwd from pc_user where u_id =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, u_id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				pwd = rs.getString(1);

				if (!pwd.equals(u_pwd)) {
					re = 0;
				} else {
					sql = "delete pc_user where u_id=?";
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, u_id);
					pstmt.executeUpdate();
					re = 1;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
	
}
