package portfolio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import myUtil.HanConv;

public class ManagerDBBean {
	private static ManagerDBBean instance = new ManagerDBBean();

	public static ManagerDBBean getInstance() {
		return instance;
	}
	
	private Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/oracle");
		return ds.getConnection();
	}
	
	public int insertManager(ManagerBean manager) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int re = -1;
		
		try {
			conn = getConnection();
			sql = "SELECT m_id FROM pc_manager";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			sql = "insert into pc_user(u_id, u_pwd) values(?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, manager.getM_id());
			pstmt.setString(2, manager.getM_pwd());
			pstmt.executeUpdate();

			re = 1;

		} catch (Exception e) {
			System.out.println("���� ");
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
	
	public ManagerBean getManager(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from pc_manager where m_id=?";
		ManagerBean manager = null;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setNString(1, id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				manager = new ManagerBean();
				manager.setM_id(rs.getString("m_id"));
				manager.setM_pwd(rs.getString("m_pwd"));
			}

		} catch (Exception e) {
			System.out.println("�ý��� ���� ");
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return manager;
	}
	
	// ���̵�� ��й�ȣ ��ġ ����
	public int checkManager(String id, String pwd) throws Exception { 
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int re = -1;
		String m_pwd = "";
		String sql = "select m_pwd from pc_manager where m_id=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				m_pwd = rs.getString("m_pwd");
				if (m_pwd.equals(pwd)) {
					re = 1;
				} else {
					re = 0;
				}
			} else {
				re = -1;
			}
			rs.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}

}
