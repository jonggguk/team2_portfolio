//package shopping;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
//import javax.naming.Context;
//import javax.naming.InitialContext;
//import javax.sql.DataSource;
//
//
//public class UserDBBean {
//
//	private static UserDBBean instance = new UserDBBean();
//
//	public static UserDBBean getInstance() {
//		return instance;
//	}
//
//	public Connection getConnection() throws Exception {
//		Context ctx = new InitialContext();
//		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/oracle");
//		return ds.getConnection();
//	}
//	public int signupUser (UserBean user) throws Exception{
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		String sql = "";
//		int re = -1;
//		int num;
//		try {
//			sql = "insert into s_user (u_name,u_id,u_pwd,u_tel,u_jumin,u_address)"
//					+ "values(?,?,?,?,?,?)";
//		} catch (Exception e) {
//			
//		}
//		
//	}
//}
