package portfolio;

import java.sql.Timestamp;

public class UserBean {
private int u_num;
private String u_name;
private String u_id;
private String u_pwd;
private String u_jumin;
private String u_email;
private String u_address;
private int u_time;
private String u_level;
private Timestamp u_rgdate;
private Timestamp u_lastuse;
private int u_mileage;

public static int pageSize = 10; 
public static int pageCount = 1;  
public static int pageNum = 1;  

public static String pageNumber(int limit) { 
	//���̴� ������ �� 4�� ó���ϴ� ����
	String str = "";
	int temp = (pageNum - 1) % limit; //������ �ѹ�
	int startPage = pageNum - temp; //���� ������ == pageNum - (pageNum - 1) % limit
	
	if((startPage - limit) > 0) {
		str = "<a href='mgurMain.jsp?pageNum=" + (startPage - 1) + "'>[����]</a>&nbsp;&nbsp;";
	}
	
	for (int i = startPage; i<(startPage + limit); i++) {
		if (i == pageNum) {
			str += "[" + i + "]&nbsp;&nbsp;";
		} else {
			str += "<a href='mgurMain.jsp?pageNum=" + i + "'>[" + i + "]</a>&nbsp;&nbsp;";
		}
		
		if(i >= pageCount) {
			break;
		}
	}		
	//����, ���� ǥ��
	if((startPage + limit) <= pageCount) {
		str += "<a href = 'mgurMain.jsp?pageNum=" + (startPage + limit) + "'> [����]</a>";
	}
	return str; 
}
public String getU_level() {
	return u_level;
}
public void setU_level(String u_level) {
	this.u_level = u_level;
}
public Timestamp getU_rgdate() {
	return u_rgdate;
}
public void setU_rgdate(Timestamp u_rgdate) {
	this.u_rgdate = u_rgdate;
}
public Timestamp getU_lastuse() {
	return u_lastuse;
}
public void setU_lastuse(Timestamp u_lastuse) {
	this.u_lastuse = u_lastuse;
}
public int getU_mileage() {
	return u_mileage;
}
public void setU_mileage(int u_mileage) {
	this.u_mileage = u_mileage;
}
public int getU_time() {
	return u_time;
}
public void setU_time(int u_time) {
	this.u_time = u_time;
}
public int getU_num() {
	return u_num;
}
public void setU_num(int u_num) {
	this.u_num = u_num;
}
public String getU_name() {
	return u_name;
}
public void setU_name(String u_name) {
	this.u_name = u_name;
}
public String getU_id() {
	return u_id;
}
public void setU_id(String u_id) {
	this.u_id = u_id;
}
public String getU_pwd() {
	return u_pwd;
}
public void setU_pwd(String u_pwd) {
	this.u_pwd = u_pwd;
}
public String getU_jumin() {
	return u_jumin;
}
public void setU_jumin(String u_jumin) {
	this.u_jumin = u_jumin;
}
public String getU_email() {
	return u_email;
}
public void setU_email(String u_email) {
	this.u_email = u_email;
}
public String getU_address() {
	return u_address;
}
public void setU_address(String u_address) {
	this.u_address = u_address;
}


}
