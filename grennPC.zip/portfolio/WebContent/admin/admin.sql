create table admin(
    admin_id varchar2(100),
    admin_password varchar2(100)
);
insert into admin values('admin', '1234');